/*
 * Behaviour.h
 *
 *  Created on: 08.06.2022
 *      Author: mrt
 */

#ifndef BEHAVIOUR_H_
#define BEHAVIOUR_H_

typedef void (*Action) (void);
typedef bool (*Condition) (void);




#endif /* BEHAVIOUR_H_ */
