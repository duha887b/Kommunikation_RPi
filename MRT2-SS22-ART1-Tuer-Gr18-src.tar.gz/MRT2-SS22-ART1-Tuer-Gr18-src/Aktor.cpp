//
// Created by dustin on 6/10/22.
//

#include "Aktor.h"

Aktor::Aktor(unsigned int port, unsigned int pin, bool state) : HardwareElement(port,pin,state) {

}
Aktor::~Aktor() {

}