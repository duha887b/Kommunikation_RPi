/*
 * Transition.cpp
 *
 *  Created on: 08.06.2022
 *      Author: mrt
 */
#include  "Transition.h"

Transition::Transition(const State& start,const State& end, Condition bed):startState(start), endState(end), bedingung(bed){


}



